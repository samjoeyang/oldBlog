#!bin/sh


function init()
{
	#import RPM-GPG-KEY and install initscripts,wget,git
	yum clean all
#	cp -rf ./repo/aliyun.repo /etc/yum.repos.d/
#	cp -rf ./repo/epel.repo /etc/yum.repos.d/
	rpm --import /etc/pki/rpm-gpg/RPM* && rpm --import http://mirrors.aliyun.com/centos/RPM-GPG-KEY-CentOS-6
	yum -y install gcc gcc-c++ bison autoconf automake initscripts wget git
}

function install_httpd()
{
	yum -y install httpd httpd-devel
	sed -i 's/#ServerName www.example.com:80/ServerName localhost:80/g' /etc/httpd/conf/httpd.conf
}

function install_nginx()
{
	echo -e "[nginx]\nname=nginx repo\nbaseurl=http://nginx.org/packages/centos/6/x86_64\ngpgcheck=0\nenabled=1" >> /etc/yum.repos.d/nginx.repo
	yum -y install nginx

}

function download_php()
{
	wget -c http://cn2.php.net/distributions/php-5.6.29.tar.bz2
}

function install_php()
{
	#install support libs
	yum -y install libxml2 libxml2-devel curl curl-devel libjpeg libjpeg-devel libpng libpng-devel libmcrypt libmcrypt-devel mhash mcrypt  libtool-ltdl libtool-ltdl-devel bzip2 bzip2-devel freetype freetype-devel openldap openldap-devel openssl openssl-devel  

	cp -frp /usr/lib64/libldap* /usr/lib/

	#install php
	tar -jxvf php-5.6.29.tar.bz2 && cd php-5.6.29 && ./configure --with-apxs2=/usr/sbin/apxs --with-mysql=mysqlnd --with-mysqli=mysqlnd  --with-mysql-sock --with-pdo-mysql=mysqlnd --with-openssl  --with-gd --with-iconv --with-jpeg-dir=/usr/local/lib --with-png-dir --with-freetype-dir --with-zlib --with-bz2 --with-libxml-dir  --with-gettext --with-curl --with-mhash --with-mcrypt --enable-mbstring --enable-mbregex --with-ldap --with-ldap-sasl --with-xmlrpc  --enable-gd-native-ttf  --enable-pdo  --enable-pcntl --enable-sockets --enable-bcmath --enable-xml --enable-zip --enable-soap --enable-bcmath --enable-shmop --enable-sysvsem --enable-inline-optimization --enable-maintainer-zts --enable-opcache --enable-cgi --without-pear --disable-phar >> ../install_php_log && make >> ../install_php_log && make install >> ../install_php_log && cd ../

	#config PHP
	cp ./php-5.6.29/php.ini-development  $(php-config --prefix)/lib/php.ini && sed -i 's/\;date\.timezone \=/date\.timezone \=PRC/g' $(php-config --prefix)/lib/php.ini && sed -i "s/\;include_path \= \"\.\:\/php\/includes\"/include_path \= \"\$\(php-config --prefix\)\/lib\/php\"/g" $(php-config --prefix)/lib/php.ini && ln -s $(php-config --prefix)/bin/php /usr/bin/php
	echo "AddHandler application/x-httpd-php .php" >> /etc/httpd/conf/httpd.conf
	echo "<?php phpinfo();?>" > /var/www/html/i.php
}

function install_phpfpm()
{
	#install support libs
	yum -y install libxml2 libxml2-devel curl curl-devel libjpeg libjpeg-devel libpng libpng-devel libmcrypt libmcrypt-devel mhash mcrypt  libtool-ltdl libtool-ltdl-devel bzip2 bzip2-devel freetype freetype-devel openldap openldap-devel openssl openssl-devel  

	cp -frp /usr/lib64/libldap* /usr/lib/

	#install php
	tar -jxvf php-5.6.29.tar.bz2 && cd php-5.6.29 && ./configure --enable-fpm --enable-cgi --with-mysql=mysqlnd --with-mysqli=mysqlnd  --with-mysql-sock --with-pdo-mysql=mysqlnd --with-openssl  --with-gd --with-iconv --with-jpeg-dir=/usr/local/lib --with-png-dir --with-freetype-dir --with-zlib --with-bz2 --with-libxml-dir  --with-gettext --with-curl --with-mhash --with-mcrypt --enable-mbstring --enable-mbregex --with-ldap --with-ldap-sasl --with-xmlrpc  --enable-gd-native-ttf  --enable-pdo  --enable-pcntl --enable-sockets --enable-bcmath --enable-xml --enable-zip --enable-soap --enable-bcmath --enable-shmop --enable-sysvsem --enable-inline-optimization --enable-maintainer-zts --enable-opcache --enable-cgi --without-pear --disable-phar >> ../install_php_log && make >> ../install_php_log && make install >> ../install_php_log && cd ../

	#config PHP
	cp ./php-5.6.29/php.ini-development  $(php-config --prefix)/lib/php.ini && sed -i 's/\;date\.timezone \=/date\.timezone \=PRC/g' $(php-config --prefix)/lib/php.ini && sed -i "s/\;include_path \= \"\.\:\/php\/includes\"/include_path \= \"\$\(php-config --prefix\)\/lib\/php\"/g" $(php-config --prefix)/lib/php.ini && ln -s $(php-config --prefix)/bin/php /usr/bin/php

	#config php-fpm.  use -t test fpm’s configs
	cp ./php-5.6.29/sapi/fpm/init.d.php-fpm /etc/init.d/php-fpm && chmod a+x /etc/init.d/php-fpm && chkconfig --add php-fpm && chkconfig php-fpm on && cp /usr/local/etc/php-fpm.conf.default /usr/local/etc/php-fpm.conf && /usr/local/sbin/php-fpm -c $(php-config --prefix)/lib/php.ini -y /usr/local/etc/php-fpm.conf -t && /usr/local/sbin/php-fpm -c $(php-config --prefix)/lib/php.ini -y /usr/local/etc/php-fpm.conf

	#write something into readme.txt
	echo -e "start php-fpm:\n/usr/local/sbin/php-fpm -c $(php-config --prefix)/lib/php.ini -y /usr/local/etc/php-fpm.conf\nstop php-fpm:\nkill -INT 'cat /usr/local/php/var/run/php-fpm.pid'\nOR\nservice php-fpm stop\nreboot php-fpm:\nkill -USR2 'cat /usr/local/php/var/run/php-fpm.pid'\nOR\nservice php-fpm reboot" >> ../readme.txt

	#config nginx
	mv /etc/nginx/conf.d/default.conf /etc/nginx/conf.d/default.conf.bak
	echo -e "server\n{\n listen 80;\n server_name localhost;\n root /var/www/zhenzhidaole;\n access_log /var/log/nginx/access_zhenzhidaole_com.log;\n error_log /var/log/nginx/error_zhenzhidaole_com.log;\n index index.html index.php;\n location ~ \.php$ {\n  fastcgi_pass 127.0.0.1:9000;\n  fastcgi_index index.php;\n  fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;\n  include fastcgi_params; \n  }\n}" >> /etc/nginx/conf.d/vhost.conf

	mkdir -p /var/www/html && echo "<?php phpinfo();?>" > /var/www/html/i.php

	service nginx restart
}

function install_php_by_yum()
{
	yum install libxml2 libxml2-devel curl curl-devel libjpeg libjpeg-devel libpng libpng-devel libmcrypt libmcrypt-devel mhash mcrypt  libtool-ltdl libtool-ltdl-devel bzip2 bzip2-devel freetype freetype-devel openldap openldap-devel openssl openssl-devel	
	yum -y install php php-mysql php-common php-gd php-mbstring php-mcrypt php-devel php-xml 
	yum -y install perl 
	yum -y install mod_python
}

function download_mysql()
{
	wget -c http://dev.mysql.com/get/Downloads/MySQL-5.7/mysql-community-client-5.7.16-1.el6.x86_64.rpm 
	wget -c http://dev.mysql.com/get/Downloads/MySQL-5.7/mysql-community-server-5.7.16-1.el6.x86_64.rpm
	wget -c http://dev.mysql.com/get/Downloads/MySQL-5.7/mysql-community-devel-5.7.16-1.el6.x86_64.rpm
	wget -c http://dev.mysql.com/get/Downloads/MySQL-5.7/mysql-community-libs-5.7.16-1.el6.x86_64.rpm
	wget -c http://dev.mysql.com/get/Downloads/MySQL-5.7/mysql-community-common-5.7.16-1.el6.x86_64.rpm
}

function install_mysql()
{
	#install mysql
	yum -y install libaio net-tools numactl
	yum -y remove mysql*

	echo -e "HOSTNAME=internal.hostname.DOMAIN.com" >> /etc/sysconfig/network

	rpm -ivh mysql-community-common-5.7.16-1.el6.x86_64.rpm && rpm -ivh mysql-community-libs-5.7.16-1.el6.x86_64.rpm && rpm -ivh mysql-community-devel-5.7.16-1.el6.x86_64.rpm && rpm -ivh mysql-community-client-5.7.16-1.el6.x86_64.rpm && rpm -ivh mysql-community-server-5.7.16-1.el6.x86_64.rpm && echo "max_allowed_packet=200M" >> /etc/my.cnf && service mysqld start 
	
	#find the default password and save it into readme.txt
	echo -e "\nmysql install information:" >> ../readme.txt
	sed -n '/A temporary password is generated for root@localhost:/p' /var/log/mysqld.log >> ../readme.txt
	echo -e "After login mysql,you need to do:\nstep 1: SET PASSWORD = PASSWORD(\"your new password\");\nstep 2: ALTER USER 'root'@'localhost' PASSWORD EXPIRE NEVER;\nstep 3: flush privileges;" >> ../readme.txt
#	echo -e "export MYSQL_HOME=/usr/local/mysql\nexport PATH=\$MYSQL_HOME/bin:\$PATH" >>/etc/profile && source /etc/profile
}

function download_ssh2()
{
	wget -c https://www.libssh2.org/download/libssh2-1.8.0.tar.gz
	wget -c http://pecl.php.net/get/ssh2-0.13.tgz
}

function install_ssh2()
{
	tar -zxvf libssh2-1.8.0.tar.gz && cd libssh2-1.8.0 && ./configure --prefix=/usr/local/libssh2 && make && make install && cd ../
	tar -zxvf ssh2-0.13.tgz && cd ssh2-0.13 && phpize && ./configure --prefix=/usr/local/ssh2 --with-ssh2=/usr/local/libssh2 && make && make install && echo "extension=ssh2.so" >> $(php-config --prefix)/lib/php.ini && cd ../
}

function download_oci()
{
#	wget -c http://download.oracle.com/otn/linux/instantclient/11204/oracle-instantclient11.2-basic-11.2.0.4.0-1.x86_64.rpm
#	wget -c http://download.oracle.com/otn/linux/instantclient/11204/oracle-instantclient11.2-devel-11.2.0.4.0-1.x86_64.rpm
	wget -c http://pecl.php.net/get/PDO_OCI-1.0.tgz
	wget -c http://pecl.php.net/get/oci8-2.0.12.tgz
}

Function install_oci()
{
	#install oci8 support oracle11grc2 
	rpm -ivh oracle-instantclient11.2-basic-11.2.0.4.0-1.x86_64.rpm && rpm -ivh oracle-instantclient11.2-devel-11.2.0.4.0-1.x86_64.rpm && echo '/usr/lib/oracle/11.2/client64/lib/' > /etc/ld.so.conf.d/oracle-x86_64.conf && ln -s /usr/lib/oracle/11.2/client64 /usr/lib/oracle/11.2/client && ln -s /usr/include/oracle/11.2/client64 /usr/include/oracle/11.2/client && echo -e "export ORACLE_HOME=/usr/lib/oracle/11.2/client64/\nexport LD_LIBRARY_PATH=/usr/lib/oracle/11.2/client64:\$LD_LIBRARY_PATH\nexport NLS_LANG=\"AMERICAN_AMERICA.AL32UTF8\"" >> /etc/profile && source /etc/profile

	tar -zxvf oci8-2.0.12.tgz && cd oci8-2.0.12 && phpize && ./configure --with-oci8=shared,instantclient,/usr/lib/oracle/11.2/client64/lib && make && make install && echo "extension=oci8.so" >> $(php-config --prefix)/lib/php.ini && cd ../

	tar -zxvf PDO_OCI-1.0.tgz && cd PDO_OCI-1.0 && ln -s /usr/include/oracle/11.2 /usr/include/oracle/10.2.0.1 && ln -s /usr/lib/oracle/11.2 /usr/lib/oracle/10.2.0.1 && sed -i '101i 11.2)\n  PHP_ADD_LIBRARY(clntsh, 1, PDO_OCI_SHARED_LIBADD)\n  \;\;' config.m4 && sed -i '10i elif test -f \$PDO_OCI_DIR/lib/libclntsh\.\$SHLIB_SUFFIX_NAME.11.2\; then\n  PDO_OCI_VERSION=11\.2' config.m4 && sed -i 's/function_entry/zend_function_entry/g' pdo_oci.c && phpize && ./configure --with-pdo-oci=instantclient,/usr,11.2 && make && make install && echo "extension=pdo_oci.so" >> $(php-config --prefix)/lib/php.ini && cd ../

}

function download_phalcon()
{
	git clone --depth=1 git://github.com/phalcon/cphalcon.git
}

function install_phalcon()
{
	#install phalcon frameworks
	cd cphalcon/build && ./install && echo "extension=phalcon.so" >> $(php-config --prefix)/lib/php.ini && cd ../../
}

function download_jdk()
{
#	http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html
}

function install_jdk()
{
	install_path=$(pwd) && mkdir -p /usr/java && cp -rf jdk-8u111-linux-x64.tar.gz /usr/java/ && cd /usr/java && tar -zxvf jdk-8u111-linux-x64.tar.gz && echo -e "JAVA_HOME=/usr/java/jdk1.8.0_111\nCLASSPATH=\$JAVA_HOME/lib/\nPATH=\$PATH:\$JAVA_HOME/bin:\$JAVA_HOME/jre/bin\nexport PATH JAVA_HOME CLASSPATH" >> /etc/profile && source /etc/profile && java -version && cd $install_path
}

function install_openssl()
{
	yum -y install openssl mod_ssl
	cd /etc/pki/tls/private/ && openssl genrsa 1024 >localhost.key && openssl req -new -key localhost.key > localhost.csr && openssl req -x509 -days 3650 -key localhost.key -in localhost.csr > localhost.crt && cp localhost.crt /etc/pki/tls/certs/localhost.crt
}

function test_http()
{
	echo -e "Alias /webalias \"/var/www/alias\”\n<Directory \"/var/www/alias\">\n    Options Indexes MultiViews FollowSymLinks\n    AllowOverride None\n    Order allow,deny\n    Allow from all\n</Directory>" >> /etc/httpd/conf/httpd.conf
	echo -e "<VirtualHost *:80>\n        ServerAdmin admin@zhenzhidaole.com\n        DocumentRoot /var/www/html\n        ServerName www.zhenzhidaole.com\n        ErrorLog /var/www/logs/error_log\n        CustomLog /var/www/logs/access_log common\n</VirtualHost>" >> /etc/httpd/conf/httpd.conf
	mkdir -p /var/www/web && mkdir -p /var/www/alias
	echo "<?php phpinfo();?>" > /var/www/alias/s.php
	echo -e "127.0.0.1	www.zhenzhidaole.com" >> /etc/hosts
	service httpd restart
}

function test_phpinfo()
{
	php -v
	php -i |grep mcrypt
	php -i |grep ssh
	php -i |grep oci
	php -i |grep phalcon
	curl https://localhost/ -k
	curl http://www.zhenzhidaole.com/c.php |grep oci


#<?php
#$con = mysqli_connect("127.0.0.1","root","!qaz@wsx");
#if (!$con)
#  {
#  die('Could not connect: ' . mysql_error());
#  }
#echo 'Connected successfully';
#mysql_close($con);
#phpinfo();
#?>
}



init()
install_httpd()
#install_nginx()
#download_php()
install_php()
#install_phpfpm()
#download_mysql()
install_mysql()
#download_ssh2()
install_ssh2()
#download_oci()
install_oci()
#download_phalcon()
install_phalcon()
#download_jdk()
install_jdk()
install_openssl()

#test_http()
#test_phpinfo()
